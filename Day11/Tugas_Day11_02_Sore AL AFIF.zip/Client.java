package Week2.Day6.Tugas2;

import java.io.*;
import java.net.Socket;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 5050);
            System.out.println("Server terhubung ke : " + socket);

            DataInputStream dis = new DataInputStream(socket.getInputStream());
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

            InputStreamReader in = new InputStreamReader(System.in);
            BufferedReader buffIn = new BufferedReader(in);

            String chatClient = "";
            String chatServer = "";
            while (!chatServer.equals("Terima Kasih...")) {
                System.out.print("Masukkan Pesan : ");
                chatClient = buffIn.readLine();
                dos.writeUTF(chatClient);
                dos.flush();
                System.out.println("Pesan Terkirim...");
                chatServer = dis.readUTF();
                System.out.println("Pesan Server : " + chatServer);
            }
            dos.close();
            socket.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
