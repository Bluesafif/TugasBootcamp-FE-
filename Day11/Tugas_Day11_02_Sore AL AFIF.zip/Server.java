package Week2.Day6.Tugas2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        try {
            // Start Server
            ServerSocket server = new ServerSocket(5050);
            System.out.println("Server started : " + server);

            // Accept Client
            Socket socket = server.accept();
            System.out.println("Client accepted : " + socket);

            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            DataInputStream dis = new DataInputStream(socket.getInputStream());

            InputStreamReader in = new InputStreamReader(System.in);
            BufferedReader buffIn = new BufferedReader(in);

            String chatServer = "";
            String chatClient = "";
            while (true) {
                chatClient = dis.readUTF();
                System.out.println("Pesan Client : " + chatClient);
                if (chatClient.equalsIgnoreCase("stop")) {
                    chatServer = "Terima Kasih...";
                    dos.writeUTF(chatServer);
                    dos.flush();
                    break;
                } else {
                    System.out.print("Masukkan Pesan : ");
                    chatServer = buffIn.readLine();
                    dos.writeUTF(chatServer);
                    dos.flush();
                }
                System.out.println("Pesan Terkirim...");
            }
            dis.close();
            socket.close();
            server.close();

        } catch (IOException e) {
            System.out.println(e);
        }
    }
}