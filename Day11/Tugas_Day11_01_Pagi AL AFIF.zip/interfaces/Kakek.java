package Week2.Day6.Tugas1.interfaces;

public interface Kakek {
    public void namaKakek(String namaKakek);
}
