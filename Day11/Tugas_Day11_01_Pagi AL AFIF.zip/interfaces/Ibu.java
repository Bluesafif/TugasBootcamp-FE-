package Week2.Day6.Tugas1.interfaces;

public interface Ibu {
    public void namaIbu(String namaIbu);
    public void sifatIbu(String sifatIbu);
}
