package Week2.Day6.Tugas1.interfaces;

public interface Ayah extends Kakek {
    public void namaAyah(String namaAyah);
    public void sifatAyah(String sifatAyah);
}
