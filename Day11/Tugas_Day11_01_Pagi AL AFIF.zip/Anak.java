package Week2.Day6.Tugas1;

import Week2.Day6.Tugas1.interfaces.Ayah;
import Week2.Day6.Tugas1.interfaces.Ibu;

import java.util.Scanner;

public class Anak implements Ayah, Ibu {
    @Override
    public void namaAyah(String namaAyah) {
        System.out.println("Nama Ayah  : " + namaAyah);
    }

    @Override
    public void sifatAyah(String sifatAyah) {
        System.out.println("Sifat Ayah : " + sifatAyah);
    }

    @Override
    public void namaIbu(String namaIbu) {
        System.out.println("Nama Ibu   : " + namaIbu);
    }

    @Override
    public void sifatIbu(String sifatIbu) {
        System.out.println("Sifat Ibu  : " + sifatIbu);
    }

    @Override
    public void namaKakek(String namaKakek) {
        System.out.println("Nama Kakek : " + namaKakek);
    }

    public void namaAnak(String namaAnak){
        System.out.println("Nama Anak  : " + namaAnak);
    }

    public void sifatAnak(String sifatAnak){
        System.out.println("Sifat Anak : " + sifatAnak);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        boolean pilih = true;

        Anak anak = new Anak();

        while (pilih) {
            System.out.println("=======================================");
            System.out.println("------------Input Data Anak------------");
            System.out.println("=======================================");
            System.out.print("Nama Anak  : ");
            String namaAnak = sc.nextLine();
            System.out.print("Sifat Ayah : ");
            String sifatAyah = sc.nextLine();
            System.out.print("Sifat Ibu  : ");
            String sifatIbu = sc.nextLine();
            System.out.print("Sifat Anak : ");
            String sifatAnak = sc.nextLine();

            System.out.println("=======================================");
            System.out.println("---------------Data Anak---------------");
            System.out.println("=======================================");
            anak.namaAnak(namaAnak);
            anak.sifatAnak(sifatAnak);
            anak.namaAyah("Rangga");
            anak.sifatAyah(sifatAyah);
            anak.namaIbu("Cinta");
            anak.sifatIbu(sifatIbu);
            anak.namaKakek("Michael");

            System.out.print("Input Data Lain [y/n]? ");
            String input = sc.nextLine();

            if (input.equalsIgnoreCase("n")){
                pilih = false;
            }
        }
    }
}
