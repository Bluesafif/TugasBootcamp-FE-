package Week2.Day8.Tugas1;

class Jabatan {
    private int idJabatan;
    private String namaJabatan;
    private int tjMakan;
    private int tjTransport;

    public int getIdJabatan() {
        return idJabatan;
    }

    public void setIdJabatan(int idJabatan) {
        this.idJabatan = idJabatan;
    }

    public String getNamaJabatan() {
        return namaJabatan;
    }

    public void setNamaJabatan(String namaJabatan) {
        this.namaJabatan = namaJabatan;
    }

    public int getTjMakan() {
        return tjMakan;
    }

    public void setTjMakan(int tjMakan) {
        this.tjMakan = tjMakan;
    }

    public int getTjTransport() {
        return tjTransport;
    }

    public void setTjTransport(int tjTransport) {
        this.tjTransport = tjTransport;
    }
}
