package Week2.Day8.Tugas1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;

public class Main {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/day8_tugas1", "root", "root");
            Statement stmt = con.createStatement();

            InputStreamReader sc = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(sc);

            boolean aktif = true;

            ProsesData a = new ProsesData();

            while (aktif) {
                System.out.println("\n---------MENU---------");
                System.out.println("[1] Jabatan");
                System.out.println("[2] Karyawan");
                System.out.println("[3] List Karyawan");
                System.out.println("[4] Keluar");
                System.out.print("Masukkan Pilihan : ");
                int pilih = 0;
                try {
                    pilih = Integer.parseInt(br.readLine());
                }catch (Exception e){
                    System.out.println("Masukkan Angka Antara 1 Sampai 4!");
                }

                switch (pilih) {
                    case 1:
                        boolean loop = true;
                        while (loop) {
                            System.out.println("\nPilihan : ");
                            System.out.println("[1] Input");
                            System.out.println("[2] Update");
                            System.out.println("[3] List Jabatan");
                            System.out.println("[4] Menu Sebelumnya");
                            System.out.print("Masukkan Pilihan Input : ");
                            int input = 0;
                            try {
                                input = Integer.parseInt(br.readLine());
                            } catch (Exception e) {
                                System.out.println("Masukkan Angka Antara 1 Sampai 3!");
                            }
                            if (input == 1) {
                                a.InputDataJabatan(stmt);
                                loop = false;
                            } else if (input == 2) {
                                a.EditJabatan(stmt);
                            } else if (input == 3) {
                                a.tampilJabatan(stmt);
                                loop = false;
                            } else if (input == 4) {
                                loop = false;
                            } else {
                                System.out.println("Pilihan Tidak Tersedia!");
                            }
                        }
                        break;
                    case 2:
                        boolean ping = true;
                        while (ping) {
                            System.out.println("\nPilihan : ");
                            System.out.println("[1] Input");
                            System.out.println("[2] Update");
                            System.out.println("[3] Delete");
                            System.out.println("[4] Delete All Karyawan");
                            System.out.println("[5] Menu Sebelumnya");
                            System.out.print("Masukkan Pilihan Input : ");
                            int pil = 0;
                            try {
                                pil = Integer.parseInt(br.readLine());
                            } catch (Exception e) {
                                System.out.println("Masukkan Angka Antara 1 Sampai 4!");
                            }
                            if (pil == 1) {
                                a.InputDataKaryawan(stmt);
                                ping = false;
                            } else if (pil == 2) {
                                a.EditKaryawan(stmt);
                                ping = false;
                            } else if (pil == 3) {
                                a.DeleteKaryawan(stmt);
                                ping = false;
                            } else if (pil == 4) {
                                a.DeleteAllKaryawan(stmt);
                                ping = false;
                            } else if (pil == 5) {
                                ping = false;
                            } else {
                                System.out.println("Pilihan Tidak Tersedia!");
                            }
                        }
                        break;
                    case 3:
                        boolean looping = true;
                        while (looping) {
                            System.out.println("\nPilihan : ");
                            System.out.println("[1] Staff");
                            System.out.println("[2] Manager");
                            System.out.println("[3] Semua Karyawan");
                            System.out.println("[4] Menu Sebelumnya");
                            System.out.print("Masukkan Pilihan Input : ");
                            int set = 0;
                            try {
                                set = Integer.parseInt(br.readLine());
                            } catch (Exception e) {
                                System.out.println("Masukkan Angka Antara 1 Sampai 3!");
                            }

                            if (set == 1) {
                                a.tampilStaff(stmt);
                                looping = false;
                            } else if (set == 2) {
                                a.tampilManager(stmt);
                                looping = false;
                            } else if (set == 3) {
                                a.tampilListKaryawan(stmt);
                                looping = false;
                            } else if (set == 4) {
                                looping = false;
                            } else {
                                System.out.println("Pilihan Tidak Tersedia!");
                            }
                        }
                        break;
                    case 4:
                        System.out.println("\n----------TERIMA KASIH----------");
                        aktif = false;
                        break;
                    default:
                        System.out.println("Pilihan Tidak Tersedia!");
                }
            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
