package Week2.Day8.Tugas1;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProsesData {
    Scanner scan = new Scanner(System.in);

    public int tanyaJumlah() {
        boolean ulangiJumlah = true;
        int jumlah = 0;
        while (ulangiJumlah) {
            System.out.print("Masukkan jumlah data : ");
            try {
                jumlah = scan.nextInt();
                ulangiJumlah = false;
            } catch (Exception e) {
                System.out.println("Masukkan Angka!");
            }
        }
        return jumlah;
    }

    public void InputDataJabatan(Statement stmt){
        try {
            System.out.println("========================================");
            System.out.println("---------------INPUT DATA---------------");
            System.out.println("========================================");
            int jumlah = tanyaJumlah();
            int i = 0;
            while (i < jumlah) {
                System.out.println("\n-------------Jabatan ke-" + (i + 1) + "-------------");
                Jabatan jab = new Jabatan();
                System.out.print("Masukkan Nama                : ");
                String nama = scan.next();
                jab.setNamaJabatan(nama);
                System.out.print("Masukkan Tunjangan Makan     : Rp.");
                int tjMakan = scan.nextInt();
                jab.setTjMakan(tjMakan);
                System.out.print("Masukkan Tunjangan Transport : Rp.");
                int tjTransport = scan.nextInt();
                jab.setTjTransport(tjTransport);
                String sql = "INSERT INTO jabatan(namaJabatan, tjMakan, tjTransport) VALUES ('" + jab.getNamaJabatan() + "','" + jab.getTjMakan() + "','" + jab.getTjTransport() + "')";
                stmt.execute(sql);
                i++;
            }
        }catch (SQLException e){
            System.out.println(e);
        }
    }

    public void InputDataKaryawan(Statement stmt){
        try {
            System.out.println("========================================");
            System.out.println("---------------INPUT DATA---------------");
            System.out.println("========================================");
            int jumlah = tanyaJumlah();
            int i = 0;
            while (i < jumlah) {
                System.out.println("\n-------------Staff ke-" + (i + 1) + "-------------");
                Karyawan kar = new Karyawan();
                System.out.print("Masukkan Nama       : ");
                String nama = scan.next();
                kar.setNama(nama);
                System.out.print("Masukkan Gaji Pokok : Rp.");
                int gajiPokok = scan.nextInt();
                kar.setGajiPokok(gajiPokok);
                System.out.println("\nID Jabatan\tNama Jabatan");
                System.out.println("================================");
                ResultSet rs = stmt.executeQuery("select * from jabatan");
                while (rs.next()) {
                    System.out.println(rs.getInt(1) + "\t\t\t" + rs.getString(2));
                }
                System.out.println("================================");
                System.out.print("\nMasukkan ID Jabatan : ");
                int idJabatan = scan.nextInt();
                kar.setIdJabatan(idJabatan);
                String sql = "INSERT INTO karyawan(nama, gajiPokok, idJabatan) VALUES ('" + kar.getNama() + "'," + kar.getGajiPokok() + "," + kar.getIdJabatan() + ")";
                stmt.execute(sql);
                i++;
            }
        }catch (SQLException e){
            System.out.println(e);
        }
    }

    public void tampilJabatan(Statement stmt){
        try {
            System.out.println("\n=======================================================================");
            System.out.println("ID Jabatan\tNama Jabatan\tTunjangan Makan\tTunjangan Transport");
            System.out.println("=======================================================================");
            ResultSet rs = stmt.executeQuery("select * from jabatan");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" + rs.getInt(3) + "\t\t\t" + rs.getInt(4));
            }
            System.out.println("=======================================================================");
        }catch (SQLException e){
            System.out.println(e);
        }
    }

    public void EditKaryawan(Statement stmt){
        try {
            try {
                System.out.println("\n====================================================");
                System.out.println("ID Karyawan\t\tNama Karyawan\tGaji Pokok");
                System.out.println("====================================================");
                ResultSet rs = stmt.executeQuery("select * from karyawan");
                while (rs.next()) {
                    System.out.println(rs.getInt(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" + rs.getInt(3));
                }
                System.out.println("====================================================");
            }catch (SQLException e){
                System.out.println(e);
            }

            ResultSet rs=stmt.executeQuery("SELECT*FROM KARYAWAN");

            System.out.print("ID Karyawan yang diedit : ");
            int id = scan.nextInt();
            int tampungID=0;
            while(rs.next()) {
                if(rs.getInt(1) == id){
                    tampungID = rs.getInt(1);
                    break;
                }
            }

            if (tampungID == id){
                Karyawan karyawan = new Karyawan();
                System.out.print("Nama            : ");
                String name = scan.next();
                karyawan.setNama(name);

                System.out.print("Gaji Pokok      : ");
                int gapok = scan.nextInt();
                karyawan.setGajiPokok(gapok);

                ResultSet rs2=stmt.executeQuery("SELECT*FROM JABATAN");

                System.out.println("\nPilih Jabatan : ");
                System.out.println("-----------------------------------");
                System.out.println("ID Jabatan\t\tNama Jabatan");
                System.out.println("-----------------------------------");
                while(rs2.next()) {
                    System.out.println(rs2.getInt(1) + "\t\t" + rs2.getString(2));
                }
                System.out.println("-----------------------------------");

                System.out.print("ID Jabatan      : ");
                int idJabatan = scan.nextInt();
                karyawan.setIdJabatan(idJabatan);

                String sql ="UPDATE karyawan SET nama = '"+karyawan.getNama()+"', gajiPokok = '"+karyawan.getGajiPokok()+"', idJabatan = '"+karyawan.getIdJabatan()+"' WHERE id = '"+id+"'";
                stmt.execute(sql);
                System.out.println("\nData Karyawan Berhasil diedit !!\n");
            }else{
                System.out.println("\nID Karyawan Tidak Ditemukan !!\n");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void EditJabatan(Statement stmt){
        try {
            tampilJabatan(stmt);

            ResultSet rs=stmt.executeQuery("SELECT*FROM jabatan");

            System.out.print("ID jabatan yang diedit : ");
            int id = scan.nextInt();
            int tampungID=0;
            while(rs.next()) {
                if(rs.getInt(1) == id){
                    tampungID = rs.getInt(1);
                    break;
                }
            }

            if (tampungID == id){
                Jabatan jab = new Jabatan();
                System.out.print("Masukkan Nama                : ");
                String nama = scan.next();
                jab.setNamaJabatan(nama);
                System.out.print("Masukkan Tunjangan Makan     : Rp.");
                int tjMakan = scan.nextInt();
                jab.setTjMakan(tjMakan);
                System.out.print("Masukkan Tunjangan Transport : Rp.");
                int tjTransport = scan.nextInt();
                jab.setTjTransport(tjTransport);

                String sql ="UPDATE jabatan SET namaJabatan = '"+jab.getNamaJabatan()+"', tjMakan = '"+jab.getTjMakan()+"', tjTransport = '"+jab.getTjTransport()+"' WHERE idJabatan = '"+id+"'";
                stmt.execute(sql);
                System.out.println("\nData Jabatan Berhasil diedit !!\n");
            }else{
                System.out.println("\nID Jabatan Tidak Ditemukan !!\n");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void DeleteKaryawan(Statement stmt){
        try {
            try {
                System.out.println("\n====================================================");
                System.out.println("ID Karyawan\t\tNama Karyawan\tGaji Pokok");
                System.out.println("====================================================");
                ResultSet rs = stmt.executeQuery("select * from karyawan");
                while (rs.next()) {
                    System.out.println(rs.getInt(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" + rs.getInt(3));
                }
                System.out.println("====================================================");
            }catch (SQLException e){
                System.out.println(e);
            }

            ResultSet rs=stmt.executeQuery("SELECT*FROM karyawan");
            System.out.print("ID Karyawan yang dihapus : ");
            int id = scan.nextInt();
            int tampungID=0;
            while(rs.next()) {
                if(rs.getInt(1) == id){
                    tampungID = rs.getInt(1);
                    break;
                }
            }
            if (tampungID == id){
                String sql = "DELETE FROM karyawan WHERE id='"+id+"'";
                stmt.execute(sql);
                System.out.println("\nData Berhasil dihapus !!\n");
            }else{
                System.out.println("\nID Tidak Ditemukan !!\n");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void DeleteAllKaryawan(Statement stmt){
        try{
            stmt.execute("DELETE FROM karyawan");
        }catch (SQLException e){
            System.out.println(e);
        }
    }

    public void tampilStaff(Statement stmt){
        try {
            ResultSet rs=stmt.executeQuery("SELECT a.id, a.nama, a.gajiPokok, b.namaJabatan, b.tjMakan, b.tjTransport FROM karyawan a INNER JOIN jabatan b ON a.idJabatan = b.idJabatan AND b.idJabatan = 8");

            System.out.println("------------------------------------------------------------------------------------");
            System.out.println("ID\tNama Karyawan\t\tGaji Pokok\t\tJabatan\t\tTun.Makan\t\tTun.Transpor");
            System.out.println("------------------------------------------------------------------------------------");

            while(rs.next()) {
                System.out.println(rs.getInt(1) + "\t" + rs.getString(2)
                        + "\t\t\t\t" + rs.getInt(3)+ "\t\t\t" + rs.getString(4)
                        + "\t\t" + rs.getInt(5)+ "\t\t\t" + rs.getInt(6));
            }

            System.out.println("------------------------------------------------------------------------------------");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void tampilManager(Statement stmt){
        try {
            ResultSet rs=stmt.executeQuery("SELECT a.id, a.nama, a.gajiPokok, b.namaJabatan, b.tjMakan, b.tjTransport FROM karyawan a INNER JOIN jabatan b ON a.idJabatan = b.idJabatan AND b.idJabatan = 9");

            System.out.println("------------------------------------------------------------------------------------");
            System.out.println("ID\tNama Karyawan\t\tGaji Pokok\t\tJabatan\t\tTun.Makan\t\tTun.Transpor");
            System.out.println("------------------------------------------------------------------------------------");

            while(rs.next()) {
                System.out.println(rs.getInt(1) + "\t" + rs.getString(2)
                        + "\t\t\t\t" + rs.getInt(3)+ "\t\t\t" + rs.getString(4)
                        + "\t\t" + rs.getInt(5)+ "\t\t\t" + rs.getInt(6));
            }

            System.out.println("------------------------------------------------------------------------------------");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void tampilKaryawan(Statement stmt){
        try {
            ResultSet rs=stmt.executeQuery("SELECT a.id, a.nama, a.gajiPokok, b.namaJabatan, b.tjMakan, b.tjTransport FROM karyawan a INNER JOIN jabatan b ON a.idJabatan = b.idJabatan");

            System.out.println("------------------------------------------------------------------------------------");
            System.out.println("ID\tNama Karyawan\t\tGaji Pokok\t\tJabatan\t\tTun.Makan\t\tTun.Transport");
            System.out.println("------------------------------------------------------------------------------------");

            while(rs.next()) {
                System.out.println(rs.getInt(1) + "\t" + rs.getString(2)
                        + "\t\t\t\t" + rs.getInt(3)+ "\t\t\t" + rs.getString(4)
                        + "\t\t" + rs.getInt(5)+ "\t\t\t" + rs.getInt(6));
            }

            System.out.println("------------------------------------------------------------------------------------");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void tampilDataJabatan(Statement stmt) throws Exception {
        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM jabatan");
        rs.next();
        int count = rs.getInt(1);
        System.out.println(count);
        int limit = 2;
        int page = (int) Math.ceil(count / (float) limit);
        int start = 0;

        int i = 0;
        while (i < page) {
            String sql = "SELECT * FROM jabatan LIMIT " + start + "," + limit;
            ResultSet result = stmt.executeQuery(sql);
            System.out.println("\nHalaman - " + (i + 1));
            System.out.println("----------------------------------------------------------");
            System.out.println("ID\tNama\t\tT Makan\t\t\tT Transport");
            System.out.println("----------------------------------------------------------");
            while (result.next()) {
                System.out.println(result.getInt("idJabatan") + "\t" +
                        result.getString("namaJabatan") + "\t\tRp." +
                        result.getInt("tjMakan") + "\t\tRp." +
                        result.getInt("tjTransport"));
            }
            System.out.println("----------------------------------------------------------");
            if (page > 1) {
                while (true) {
                    System.out.print("Lihat data selanjutnya (Y/N) ? ");
                    String jawaban = scan.nextLine();
                    if (jawaban.equalsIgnoreCase("Y")) {
                        start += limit;
                        i++;
                        break;
                    } else if (jawaban.equalsIgnoreCase("n")) {
                        System.out.println("Terima Kasih.....");
                        i += page;
                        break;
                    } else {
                        System.out.println("Pilihan tidak ada !!!");
                    }
                }
            } else {
                start += limit;
                i++;
            }
        }
    }
}
