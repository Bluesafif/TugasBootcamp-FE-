package TugasBootcamp.Week1.Day4.Tugas1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static ArrayList<Mahasiswa> mahaS = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        boolean pilihan = true;
        while (pilihan) {
            System.out.println("========================================");
            System.out.println("------------------MENU------------------");
            System.out.println("========================================");
            System.out.println("1. Input Data Mahasiswa");
            System.out.println("2. Tampilkan Laporan Mahasiswa");
            System.out.println("3. Tampilkan di layar dan Export ke .txt");
            System.out.println("4. Keluar");
            System.out.print("Masukkan Pilihan : ");
            int pil = 0;
            try {
                pil = sc.nextInt();
            } catch (Exception e) {
                System.out.println("Masukkan Angka (1) sampai (5)!");
            }
            sc.nextLine();
            switch (pil) {
                case 1:
                    inputData();
                    break;
                case 2:
                    urutkanNama();
                    tampilData();
                    break;
                case 3:
                    Export export = new Export();
                    Tampil tampil = new Tampil();

                    try {
                        export.start();
                        export.join();

                        tampil.start();
                        tampil.join();
                    } catch (InterruptedException e) {
                        System.out.println(e);
                    }
                    break;
                case 4:
                    System.out.println("================================================================");
                    System.out.println("----------------------Program Selesai---------------------------");
                    System.out.println("================================================================");
                    pilihan = false;
                    break;
                default:
                    System.out.println("Pilihan Anda Tidak Tersedia");
            }
        }
    }

    public static int tanyaJumlah() {
        boolean ulangiJumlah = true;
        int jumlah = 0;
        while (ulangiJumlah) {
            System.out.print("Masukkan jumlah data : ");
            try {
                jumlah = sc.nextInt();
                ulangiJumlah = false;
            } catch (Exception e) {
                System.out.println("Masukkan Angka!");
            }
            sc.nextLine();
        }
        return jumlah;

    }

    public static int cariID(int id) {
        int index = -1;
        int i = 0;
        for (Mahasiswa mhs : mahaS) {
            if (mhs.getIdMahasiswa() == id) {
                index = i;
            }
            i++;
        }
        return index;
    }

    public static void inputData() {
        System.out.println("========================================");
        System.out.println("---------------INPUT DATA---------------");
        System.out.println("========================================");
        int jumlah = tanyaJumlah();
        int i = 0;
        while (i < jumlah) {
            System.out.println("-----------------------------------------");
            System.out.println("Data Mahasiswa Ke-" + (i + 1));
            Mahasiswa mhs = new Mahasiswa();
            boolean tanyaId = true;
            while (tanyaId) {
                System.out.print("ID\t\t: ");
                int id = 0;
                try {
                    id = sc.nextInt();
                    int index = cariID(id);
                    if (index < 0) {
                        mhs.setIdMahasiswa(id);
                        tanyaId = false;
                    } else {
                        System.out.println("ID telah digunakan!");
                    }
                } catch (Exception e) {
                    System.out.println("Masukkan Angka!");
                }
                sc.nextLine();
            }
            System.out.print("Nama\t: ");
            String nama = sc.next();
            mhs.setNama(nama);
            mahaS.add(mhs);
            int indx = mahaS.size() - 1;
            boolean jmlNilai = true;
            int jmlh = 0;
            while (jmlNilai) {
                System.out.print("Masukkan Jumlah Data Nilai : ");
                try {
                    jmlh = sc.nextInt();
                    jmlNilai = false;
                } catch (Exception e) {
                    System.out.println("Masukkan Angka!");
                }
                sc.nextLine();
            }
            for (int j = 0; j < jmlh; j++) {
                Nilai nilai = new Nilai();
                boolean binggris = true;
                while (binggris) {
                    System.out.print("Nilai Bahasa Inggris\t\t: ");
                    try {
                        double inggris = sc.nextDouble();
                        nilai.setbInggris(inggris);
                        binggris = false;
                    } catch (Exception e) {
                        System.out.println("Masukan Angka!");
                    }
                    sc.nextLine();
                }
                boolean fis = true;
                while (fis) {
                    System.out.print("Nilai Fisika\t\t: ");
                    try {
                        double fisika = sc.nextDouble();
                        nilai.setFisika(fisika);
                        fis = false;
                    } catch (Exception e) {
                        System.out.println("Masukan Angka!");
                    }
                    sc.nextLine();
                }
                boolean alg = true;
                while (alg) {
                    System.out.print("Nilai Algoritma\t\t: ");
                    try {
                        double algoritma = sc.nextDouble();
                        nilai.setAlgoritma(algoritma);
                        alg = false;
                    } catch (Exception e) {
                        System.out.println("Masukan Angka!");
                    }
                    sc.nextLine();
                }
                mahaS.get(indx).setNilai(nilai);
            }
            i++;
        }
    }

    public static void tampilData() {
        if (mahaS.size() > 0) {
            System.out.println("========================================");
            System.out.println("-------------DATA MAHASISWA-------------");
            System.out.println("========================================");
            System.out.println("ID\tNama\tBahasa Inggris\tFisika\tAlgoritma");
            for (int i = 0; i < mahaS.size(); i++) {
                String tampil = "";
                tampil += mahaS.get(i).getIdMahasiswa() + "\t" + mahaS.get(i).getNama();
                int j = 0;
                for (Nilai n : mahaS.get(i).getNilai()) {
                    if (j == 0) {
                        tampil += "\t\t" + n.getbInggris() + "\t\t" + n.getFisika() + "\t\t" + n.getAlgoritma() + "\n";
                    } else {
                        tampil += " \t\t\t\t" + n.getbInggris() + "\t\t" + n.getFisika() + "\t\t" + n.getAlgoritma() + "\n";
                    }
                    j++;
                }
                System.out.print(tampil);
            }
        } else {
            System.out.println("DATA KOSONG");
        }
    }

    public static void urutkanNama() {
        for (int i = 0; i < mahaS.size(); i++) {
            for (int j = 0; j < mahaS.size() - 1; j++) {
                Mahasiswa tempMahasiswa = mahaS.get(j);
                if (mahaS.get(j).getIdMahasiswa() < mahaS.get(j + 1).getIdMahasiswa()) {
                    mahaS.set(j, mahaS.get(j + 1));
                    mahaS.set(j + 1, tempMahasiswa);
                }
            }
        }
    }

    public static String cetakLaporan() {
        String tampil = "";
        tampil += "-------------DATA MAHASISWA-------------";
        tampil += "\nID\tNama\tBahasa Inggris\tFisika\tAlgoritma\n";
        for (int i = 0; i < mahaS.size(); i++) {
            tampil += mahaS.get(i).getIdMahasiswa() + "\t" + mahaS.get(i).getNama();
            int j = 0;
            for (Nilai n : mahaS.get(i).getNilai()) {
                if (j == 0) {
                    tampil += "\t\t" + n.getbInggris() + "\t\t" + n.getFisika() + "\t\t" + n.getAlgoritma() + "\n";
                } else {
                    tampil += " \t\t\t\t" + n.getbInggris() + "\t\t" + n.getFisika() + "\t\t" + n.getAlgoritma() + "\n";
                }
                j++;
            }
        }
        return tampil;
    }
}
