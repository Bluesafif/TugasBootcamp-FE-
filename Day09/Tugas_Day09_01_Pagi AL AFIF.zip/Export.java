package TugasBootcamp.Week1.Day4.Tugas1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Export extends Thread{

    @Override
    public void run() {
        try {
            FileWriter fw = new FileWriter("C:\\Users\\user\\OneDrive\\laporanMahasiswa.txt");
            BufferedWriter buffer = new BufferedWriter(fw);

            String tampil = Main.cetakLaporan();

            buffer.write(tampil);
            buffer.close();
            fw.close();
        } catch (IOException e){
            System.out.println(e);
        }
    }
}
