package TugasBootcamp.Week1.Day4.Tugas1;

import java.io.FileReader;

public class Tampil extends Thread {
    @Override
    public void run() {
        try{
            FileReader myFile = new FileReader("C:\\Users\\user\\OneDrive\\laporanMahasiswa.txt");
            int j;
            while ((j=myFile.read())!=-1){
                System.out.print((char)j);
            }
            myFile.close();
        }catch (Exception e){
            System.out.println("Data Tidak Terbuat!");
        }
    }
}
