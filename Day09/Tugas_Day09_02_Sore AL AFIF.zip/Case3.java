package TugasBootcamp.Week1.Day4.Tugas2;

public class Case3 extends Thread{
    Main main = new Main();

    public void run(){
        main.pullingData();
        main.sortByAscending();
        main.sortByDescending();
    }
}
