package TugasBootcamp.Week1.Day4.Tugas2;

import java.io.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main extends Thread{
    static Scanner sc = new Scanner(System.in);
    static String[] array;

    static ExecutorService executor = Executors.newFixedThreadPool(5);

    public static void main(String[] args) throws FileNotFoundException {
        menu();
    }

    public static void menu() {
        boolean pilihan = true;
        while (pilihan) {
            System.out.println("========================================");
            System.out.println("------------------MENU------------------");
            System.out.println("========================================");
            System.out.println("1. Buat Simple Thread");
            System.out.println("2. Buat Thread Pool");
            System.out.println("3. Cetak Hasil Thread");
            System.out.println("4. Keluar");
            System.out.print("Masukkan Pilihan : ");
            int pil = sc.nextInt();

            switch (pil){
                case 1:
                    Main main = new Main();
                    Thread th = new Thread(main);

                    try {
                        th.start();
                        th.join();
                    }catch (InterruptedException e){
                        System.out.println(e);
                    }

                    break;
                case 2:
                    for (int i = 1; i <= 10; i++) {
                        Runnable worker = new Case2();
                        executor.execute(worker);
                    }
                    executor.shutdown();
                    while (!executor.isTerminated()) {
                    }
                    break;
                case 3:
                    Case3 a = new Case3();

                    try {
                        a.start();
                        a.join();
                    }catch (InterruptedException e){
                        System.out.println(e);
                    }
                    break;
                case 4:
                    System.out.println("------------TERIMA KASIH------------");
                    pilihan = false;
                    break;
                default:
            }
        }
    }

    public void readTxt() {
        try {
            FileReader fr = new FileReader("C:\\Users\\user\\IdeaProjects\\Test\\src\\TugasBootcamp\\Week1\\Day4\\Tugas2\\data.txt");

            int j;
            String data = "";
            while ((j = fr.read()) != -1) {
                data = data + (char) j;
            }
            array = data.split(",", 100);
            fr.close();
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public void pullingData() {
        readTxt();
        System.out.println("-------------------------------------");
        System.out.println("           Showing 10 Data           ");
        System.out.println("-------------------------------------");
        for (int i=0; i<10;i++){
            System.out.println(array[i]);
        }
        System.out.println("-------------------------------------");
    }

    public void sortByAscending(){
        try{
            FileWriter fw = new FileWriter("C:\\Users\\user\\IdeaProjects\\Test\\src\\TugasBootcamp\\Week1\\Day4\\Tugas2\\DataAsc.txt");
            BufferedWriter br = new BufferedWriter(fw);

            br.write("-------------------------------\n");
            br.write("       DATA ASCENDING \n");
            br.write("-------------------------------\n");

            readTxt();
            Arrays.sort(array);

            for (String a : array){
                br.write("|             "+a+"            |\n");
            }

            br.write("-------------------------------\n");

            br.close();
            fw.close();
            System.out.println("\nSuccess...");
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public void sortByDescending(){
        try{
            FileWriter myFile = new FileWriter("C:\\Users\\user\\IdeaProjects\\Test\\src\\TugasBootcamp\\Week1\\Day4\\Tugas2\\DataDesc.txt");
            BufferedWriter buffer = new BufferedWriter(myFile);

            buffer.write("-------------------------------\n");
            buffer.write("       DATA DESCENDING \n");
            buffer.write("-------------------------------\n");

            readTxt();
            Arrays.sort(array, Collections.reverseOrder());

            for (String a : array){
                buffer.write("|             "+a+"            |\n");
            }

            buffer.write("-------------------------------\n");

            buffer.close();
            myFile.close();
            System.out.println("\nSuccess...");
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public void AmbilPollData(){
        readTxt();
        for (int i=0; i<10;i++){
            System.out.println(Thread.currentThread().getName()+" Data : "+array[i]);
        }
    }

    @Override
    public void run() {
        pullingData();
    }
}
