package TugasBootcamp.Week1.Day4.Tugas2;

import java.io.FileReader;

public class Case2 implements Runnable{
    String[] array;

    public void readTxt() {
        try {
            FileReader fr = new FileReader("C:\\Users\\user\\IdeaProjects\\Test\\src\\TugasBootcamp\\Week1\\Day4\\Tugas2\\data.txt");

            int j;
            String data = "";
            while ((j = fr.read()) != -1) {
                data = data + (char) j;
            }
            array = data.split(",", 100);
            fr.close();
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public void AmbilPollData(){
        readTxt();
        for (int i=0; i<10;i++){
            System.out.println(Thread.currentThread().getName()+" Data : "+array[i]);
        }
    }

    @Override
    public void run() {
        AmbilPollData();
    }
}
