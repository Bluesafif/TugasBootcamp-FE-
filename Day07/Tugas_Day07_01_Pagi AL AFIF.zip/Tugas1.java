package TugasBootcamp.Week1.Day2;


import java.util.ArrayList;
import java.util.Scanner;

public class Tugas1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ArrayList<Staff> staff = new ArrayList<Staff>();
        boolean aktif = true;

        while (aktif){
            System.out.println("OPTION");
            System.out.println("[1] Input Staff");
            System.out.println("[2] Absensi");
            System.out.println("[3] Tampilkan Laporan Staff");
            System.out.println("[4] Keluar");
            System.out.print("Masukkan Pilihan : ");
            int pilih = sc.nextInt();
            switch (pilih){
                case 1 :
                    System.out.println("Masukkan Jumlah Data : ");
                    int data = sc.nextInt();
                    for(int i = 1; i <= data; i++){
                        int idKaryawan = i;
                        System.out.println("Staff ke-"+(i));
                        System.out.print("Masukkan Nama : ");
                        String nama = sc.next();
                        System.out.print("Masukkan Jabatan : ");
                        String jabatan = sc.next();
                        Staff staff1 = new Staff(idKaryawan, nama, jabatan);
                        staff1.setAbsensi(0);
                        staff.add(staff1);
                    }
                    break;
                case 2 :
                    System.out.print("Masukkan Absensi ID Karyawan : ");
                    int idKaryawan = sc.nextInt();
                    Staff cari = null;
                    for(int i = 0; i < staff.size(); i++){
                        if (staff.get(i).getIdKaryawan() == idKaryawan){
                            cari = staff.get(i);
                            break;
                        }
                    }
                    if (cari != null){
                        cari.Absensi();
                        System.out.println("Karyawan Dengan ID "+cari.getIdKaryawan()+" berhasil absensi!");
                    } else {
                        System.out.println("Karyawan Dengan ID "+idKaryawan+" tidak ditemukan!");
                    }
                    break;
                case 3 :
                    System.out.println("\tID\tNama\tJabatan\t");
                    for(int i = 0; i < staff.size(); i++) {
                        System.out.print(staff.get(i).getIdKaryawan()+"\t");
                        System.out.print(staff.get(i).getNama()+"\t");
                        System.out.print(staff.get(i).getJabatan()+"\t");
                        System.out.println(staff.get(i).getAbsensi());
                        System.out.println();
                    }
                    System.out.println();
                    break;
                case 4 :
                    System.out.println("--------Terima Kasih--------");
                    aktif = false;
                    break;
                default:
                    System.out.println("Pilihan Tidak Tersedia!");
            }
        }
    }
}
