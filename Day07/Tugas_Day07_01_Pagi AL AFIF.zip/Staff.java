package TugasBootcamp.Week1.Day2;

import java.util.ArrayList;

public class Staff extends Worker{
    private String jabatan;

    public Staff(int idKaryawan, String nama, String jabatan) {
        super(idKaryawan, nama);
        this.jabatan = jabatan;
    }

    public String getJabatan() {
        return jabatan;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }

    @Override
    public void Absensi() {
        this.setAbsensi(this.getAbsensi() + 1);
    }
}
