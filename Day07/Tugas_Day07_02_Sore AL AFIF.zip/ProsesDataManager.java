package TugasBootcamp.Week1.Day2.Tugas2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

public class ProsesDataManager {
    InputStreamReader sc = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(sc);

    LinkedList<Manager> listManager = new LinkedList<Manager>();

    public void InputData() throws IOException {
        System.out.print("\nMasukkan Jumlah Data : ");
        int data = Integer.parseInt(br.readLine());
        try {
            for (int i = 1; i <= data ; i++) {
                System.out.println("\n-------------Manager ke-" + (i) + "-------------");
                System.out.print("Masukkan ID              : ");
                int idKaryawan = Integer.parseInt(br.readLine());
                System.out.print("Masukkan Nama            : ");
                String nama = br.readLine();
                System.out.print("Masukkan Gaji Pokok      : Rp.");
                int gajiPokok = Integer.parseInt(br.readLine());
                System.out.print("Masukkan Tunjangan Pulsa : Rp.");
                int tjPulsa = Integer.parseInt(br.readLine());
                Manager manager = new Manager(idKaryawan, nama, tjPulsa, gajiPokok, 0, 0, 0, 0);
                listManager.add(manager);
                System.out.println("-----------------------------------------------\n");
            }
        }catch (Exception e){
            System.out.println("Input Data Error!");
        }
    }

    public void AbsenManager() throws IOException {
        System.out.print("\nMasukkan ID Karyawan : ");
        int idKaryawan = Integer.parseInt(br.readLine());
        Manager cari = null;
        for(int i = 0; i < listManager.size(); i++){
            if (listManager.get(i).getIdKaryawan() == idKaryawan){
                cari = listManager.get(i);
                break;
            }
        }
        if (cari != null && cari.getAbsensiHari() <= 20){
            cari.Absensi();
            System.out.println("Karyawan Dengan Nama "+cari.getNama()+" berhasil absensi!");
        } else {
            System.out.println("Karyawan Dengan ID "+idKaryawan+" tidak ditemukan!");
        }
    }

    public void HitungTunjangan() throws Exception {
        System.out.print("\nMasukkan ID Karyawan : ");
        int idKaryawan = Integer.parseInt(br.readLine());
        Manager cari = null;
        for(int i = 0; i < listManager.size(); i++){
            if (listManager.get(i).getIdKaryawan() == idKaryawan){
                cari = listManager.get(i);
                break;
            }
        }
        if (cari != null){
            cari.getTjTransport();
            System.out.print("Masukkan Lama Entertain (hari) : ");
            int lama = Integer.parseInt(br.readLine());
            int tjEntertain = lama * 500000;
            cari.setTjEntertain(tjEntertain);
            System.out.println("Tunjangan Makan Karyawan Dengan Nama "+cari.getNama()+" berhasil dihitung!");
        } else {
            System.out.println("Karyawan Dengan ID "+idKaryawan+" tidak ditemukan!");
        }
    }

    public void HitungTotalGaji() throws Exception {
        System.out.print("\nMasukkan ID Karyawan : ");
        int idKaryawan = Integer.parseInt(br.readLine());
        Manager cari = null;
        for(int i = 0; i < listManager.size(); i++){
            if (listManager.get(i).getIdKaryawan() == idKaryawan){
                cari = listManager.get(i);
                break;
            }
        }
        if (cari != null){
            cari.getTotalGaji();
            System.out.println("Total Gaji Karyawan Dengan Nama "+cari.getNama()+" berhasil dihitung!");
        } else {
            System.out.println("Karyawan Dengan ID "+idKaryawan+" tidak ditemukan!");
        }
    }

    public void TampilData() {
        System.out.println("----------------------------------------------------MANAGER----------------------------------------------------");
        System.out.println("ID\tNama\tTunjangan Pulsa\t\tGaji Pokok\t\tAbsensi\t\tTunjangan Transport\t\tTunjangan Entertain\t\t Total Gaji");
        System.out.println("---------------------------------------------------------------------------------------------------------------");
        for(int i = 0; i < listManager.size(); i++) {
            System.out.print(listManager.get(i).getIdKaryawan()+"\t");
            System.out.print(listManager.get(i).getNama()+"\t\t");
            System.out.print(listManager.get(i).getTjPulsa()+"\t\t\t\t");
            System.out.print(listManager.get(i).getGajiPokok()+"\t\t\t");
            System.out.print(listManager.get(i).getAbsensiHari()+"\t\t\t");
            System.out.print(listManager.get(i).getTjTransport()+"\t\t\t\t");
            System.out.print(listManager.get(i).getTjEntertain()+"\t\t\t\t");
            System.out.println(listManager.get(i).getTotalGaji());
        }
        System.out.println("===============================================================================================================");
    }
}
