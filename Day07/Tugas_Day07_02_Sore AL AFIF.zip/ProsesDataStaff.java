package TugasBootcamp.Week1.Day2.Tugas2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

public class ProsesDataStaff {
    InputStreamReader sc = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(sc);

    LinkedList<Staff> listStaff = new LinkedList<Staff>();

    public void InputData() throws IOException {
        System.out.print("\nMasukkan Jumlah Data : ");
        int data = Integer.parseInt(br.readLine());
        try {
            for (int i = 1; i <= data; i++) {
                System.out.println("\n-------------Staff ke-" + (i) + "-------------");
                System.out.print("Masukkan ID              : ");
                int idKaryawan = Integer.parseInt(br.readLine());
                System.out.print("Masukkan Nama            : ");
                String nama = br.readLine();
                System.out.print("Masukkan Gaji Pokok      : Rp.");
                int gajiPokok = Integer.parseInt(br.readLine());
                System.out.print("Masukkan Tunjangan Pulsa : Rp.");
                int tjPulsa = Integer.parseInt(br.readLine());
                Staff staff = new Staff(idKaryawan, nama, tjPulsa, gajiPokok, 0, 0,0);
                listStaff.add(staff);
                System.out.println("-----------------------------------------------\n");
            }
        }catch (Exception e){
            System.out.println("Input Data Error!");
        }
    }

    public void AbsenStaff() throws IOException {
        System.out.print("\nMasukkan ID Karyawan : ");
        int idKaryawan = Integer.parseInt(br.readLine());
        Staff cari = null;
        for(int i = 0; i < listStaff.size(); i++){
            if (listStaff.get(i).getIdKaryawan() == idKaryawan){
                cari = listStaff.get(i);
                break;
            }
        }
        if (cari != null && cari.getAbsensiHari() <= 2){
            cari.Absensi();
            System.out.println("Karyawan Dengan Nama "+cari.getNama()+" berhasil absensi!");
        } else if (cari != null && cari.getAbsensiHari() > 2) {
            System.out.println("Karyawan Dengan Nama "+cari.getNama()+" sudah memenuhi absensi!");
        } else {
            System.out.println("Karyawan Dengan ID "+idKaryawan+" tidak ditemukan!");
        }
    }
    public void HitungTunjanganMakan() throws Exception{
        System.out.print("\nMasukkan ID Karyawan : ");
        int idKaryawan = Integer.parseInt(br.readLine());
        Staff cari = null;
        for(int i = 0; i < listStaff.size(); i++){
            if (listStaff.get(i).getIdKaryawan() == idKaryawan){
                cari = listStaff.get(i);
                break;
            }
        }
        if (cari != null){
            cari.getTjMakan();
            System.out.println("Tunjangan Makan Karyawan Dengan Nama "+cari.getNama()+" berhasil dihitung!");
        } else {
            System.out.println("Karyawan Dengan ID "+idKaryawan+" tidak ditemukan!");
        }
    }

    public void HitungTotalGaji() throws Exception{
        System.out.print("\nMasukkan ID Karyawan : ");
        int idKaryawan = Integer.parseInt(br.readLine());
        Staff cari = null;
        for(int i = 0; i < listStaff.size(); i++){
            if (listStaff.get(i).getIdKaryawan() == idKaryawan){
                cari = listStaff.get(i);
                break;
            }
        }
        if (cari != null){
            cari.getTotalGaji();
            System.out.println("Total Gaji Karyawan Dengan Nama "+cari.getNama()+" berhasil dihitung!");
        } else {
            System.out.println("Karyawan Dengan ID "+idKaryawan+" tidak ditemukan!");
        }
    }

    public void TampilData(){
        System.out.println("----------------------------------------------STAFF----------------------------------------------");
        System.out.println("ID\tNama\tTunjangan Pulsa\t\tGaji Pokok\t\tAbsensi\t\tTunjangan Makan\t\tTotal Gaji");
        System.out.println("-------------------------------------------------------------------------------------------------");
        for(int i = 0; i < listStaff.size(); i++) {
            System.out.print(listStaff.get(i).getIdKaryawan()+"\t");
            System.out.print(listStaff.get(i).getNama()+"\t\t");
            System.out.print(listStaff.get(i).getTjPulsa()+"\t\t\t\t");
            System.out.print(listStaff.get(i).getGajiPokok()+"\t\t\t");
            System.out.print(listStaff.get(i).getAbsensiHari()+"\t\t\t");
            System.out.print(listStaff.get(i).getTjMakan()+"\t\t");
            System.out.println(listStaff.get(i).getTotalGaji());
        }
        System.out.println("=================================================================================================");
    }
}
