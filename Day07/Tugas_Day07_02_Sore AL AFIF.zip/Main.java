package TugasBootcamp.Week1.Day2.Tugas2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        InputStreamReader sc = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(sc);

        boolean aktif = true;

        ProsesDataStaff a = new ProsesDataStaff();
        ProsesDataManager b = new ProsesDataManager();

        try{
            while (aktif){
                System.out.println("\n---------MENU---------");
                System.out.println("[1] Input Karyawan");
                System.out.println("[2] Absensi Karyawan");
                System.out.println("[3] Hitung Tunjangan");
                System.out.println("[4] Hitung Total Gaji");
                System.out.println("[5] Laporan Gaji");
                System.out.println("[6] Keluar");
                System.out.print("Masukkan Pilihan : ");
                int pilih = Integer.parseInt(br.readLine());

                switch (pilih){
                    case 1 :
                        System.out.println("\nPilihan Input : ");
                        System.out.println("[1] Staff");
                        System.out.println("[2] Manager");
                        System.out.print("Masukkan Pilihan Input : ");
                        int input = Integer.parseInt(br.readLine());

                        try {
                            if (input == 1) {
                                a.InputData();
                            } else if (input == 2) {
                                b.InputData();
                            } else {
                                System.out.println("Pilihan Tidak Tersedia!");
                            }
                        } catch (Exception e){
                            System.out.println("Masukkan Angka 1 dan 2.");
                        }
                        break;
                    case 2 :
                        System.out.println("\nPilihan Absen : ");
                        System.out.println("[1] Staff");
                        System.out.println("[2] Manager");
                        System.out.print("Masukkan Pilihan Input : ");
                        int absen = Integer.parseInt(br.readLine());
                        try {
                            if (absen == 1) {
                                a.AbsenStaff();
                            } else if (absen == 2) {
                                b.AbsenManager();
                            } else {
                                System.out.println("Pilihan Tidak Tersedia!");
                            }
                        } catch (Exception e){
                            System.out.println("Masukkan Angka 1 dan 2.");
                        }
                        break;
                    case 3 :
                        System.out.println("\nPilihan Hitung Tunjangan : ");
                        System.out.println("[1] Staff");
                        System.out.println("[2] Manager");
                        System.out.print("Masukkan Pilihan Input : ");
                        int pil = Integer.parseInt(br.readLine());
                        try{
                            if (pil == 1){
                                a.HitungTunjanganMakan();
                            }else if (pil == 2){
                                b.HitungTunjangan();
                            }else{
                                System.out.println("Pilihan Tidak Tersedia!");
                            }
                        } catch (Exception e){
                            System.out.println("Masukkan Angka 1 dan 2.");
                        }
                        break;
                    case 4 :
                        System.out.println("\nPilihan Hitung Tunjangan : ");
                        System.out.println("[1] Staff");
                        System.out.println("[2] Manager");
                        System.out.print("Masukkan Pilihan Input : ");
                        int p = Integer.parseInt(br.readLine());

                        try {
                            if (p == 1) {
                                a.HitungTotalGaji();
                            } else if (p == 2) {
                                b.HitungTotalGaji();
                            } else {
                                System.out.println("Pilihan Tidak Tersedia!");
                            }
                        } catch (Exception e){
                            System.out.println("Masukkan Angka 1 dan 2.");
                        }
                        break;
                    case 5 :
                        a.TampilData();
                        b.TampilData();
                        break;
                    case 6 :
                        System.out.println("\n----------TERIMA KASIH----------");
                        aktif = false;
                        break;
                    default:
                        System.out.println("Pilihan Tidak Tersedia!");
                }
            }
        } catch (Exception e){
            System.out.println("Masukkan Angka 1 Sampai 6.");
        }
    }
}
