package TugasBootcamp.Week1.Day2.Tugas2;

public abstract class Worker {
    private int idKaryawan;
    private String nama;
    private int tjPulsa;
    private int gajiPokok;
    private int absensiHari;
    public abstract void Absensi();

    public Worker(int idKaryawan, String nama, int tjPulsa, int gajiPokok, int absensiHari) {
        this.idKaryawan = idKaryawan;
        this.nama = nama;
        this.tjPulsa = tjPulsa;
        this.gajiPokok = gajiPokok;
        this.absensiHari = absensiHari;
    }

    public int getIdKaryawan() {
        return idKaryawan;
    }

    public void setIdKaryawan(int idKaryawan) {
        this.idKaryawan = idKaryawan;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getTjPulsa() {
        return tjPulsa;
    }

    public void setTjPulsa(int tjPulsa) {
        this.tjPulsa = tjPulsa;
    }

    public int getGajiPokok() {
        return gajiPokok;
    }

    public void setGajiPokok(int gajiPokok) {
        this.gajiPokok = gajiPokok;
    }

    public int getAbsensiHari() {
        return absensiHari;
    }

    public void setAbsensiHari(int absensiHari) {
        this.absensiHari = absensiHari;
    }
}
