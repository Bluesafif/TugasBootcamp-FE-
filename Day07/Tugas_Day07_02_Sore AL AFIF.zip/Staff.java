package TugasBootcamp.Week1.Day2.Tugas2;

class Staff extends Worker{
    private int tjMakan;
    private int totalGaji;

    public Staff(int idKaryawan, String nama, int tjPulsa, int gajiPokok, int absensiHari, int tjMakan, int totalGaji) {
        super(idKaryawan, nama, tjPulsa, gajiPokok, absensiHari);
        this.tjMakan = tjMakan;
    }

    public int getTjMakan() {
        return tjMakan = getAbsensiHari() * 20000;
    }

    public void setTjMakan(int tjMakan) {
        this.tjMakan = tjMakan;
    }

    public int getTotalGaji(){
        return totalGaji = getTjPulsa() + getTjMakan() + getGajiPokok();
    }

    @Override
    public void Absensi() {
        this.setAbsensiHari(this.getAbsensiHari() + 1);
    }
}
