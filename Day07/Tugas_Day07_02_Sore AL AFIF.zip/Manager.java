package TugasBootcamp.Week1.Day2.Tugas2;

public class Manager extends Worker{
    private int tjTransport;
    private int tjEntertain;
    private int totalGaji;

    public Manager(int idKaryawan, String nama, int tjPulsa, int gajiPokok, int absensiHari, int tjTransport, int tjEntertain, int totalGaji) {
        super(idKaryawan, nama, tjPulsa, gajiPokok, absensiHari);
        this.tjTransport = tjTransport;
        this.tjEntertain = tjEntertain;
    }

    public int getTjTransport() {
        return tjTransport = getAbsensiHari() * 50000;
    }

    public void setTjTransport(int tjTransport) {
        this.tjTransport = tjTransport;
    }

    public int getTjEntertain() {
        return tjEntertain;
    }

    public void setTjEntertain(int tjEntertain) {
        this.tjEntertain = tjEntertain;
    }

    public int getTotalGaji(){
        return totalGaji = getTjPulsa() + getTjTransport() + getTjEntertain() + getGajiPokok();
    }

    public void Absensi() {
        this.setAbsensiHari(this.getAbsensiHari() + 1);
    }
}
